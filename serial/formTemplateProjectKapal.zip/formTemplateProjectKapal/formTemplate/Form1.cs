﻿using System;
using System.Windows.Forms;

namespace formTemplate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            comPortAvaliable();
            comboBoxBaudRate.SelectedIndex = 0;
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            

            if (serialPort1.IsOpen)
            {
                serialPort1.Close();

                timerDisplayData.Enabled = false;
                buttonConnect.Text = "Connect";
            }
            else
            {
                serialPort1.PortName = comboBoxComPort.Text;
                serialPort1.BaudRate = Convert.ToInt32(comboBoxBaudRate.Text);
                serialPort1.Open();

                timerDisplayData.Enabled = true;
                buttonConnect.Text = "Disconnect";
            }

        }

        


        private void comPortAvaliable()
        {
            comboBoxComPort.Items.Clear();
            foreach (string port_name in System.IO.Ports.SerialPort.GetPortNames())
            {
                System.IO.Ports.SerialPort myPort = new System.IO.Ports.SerialPort(port_name);
                comboBoxComPort.Items.Add(port_name);

                comboBoxComPort.Text = port_name;
            }
        }


        string[] dataParse;
        private void timerDisplayData_Tick(object sender, EventArgs e)
        {
            if(serialPort1.IsOpen)
            {
                labelApi1.Text = api1.ToString();
                labelAsap1.Text = asap1.ToString();
                //textBoxIndikator1.Text = indikator1.ToString();
                

                labelApi2.Text = api2.ToString();
                labelAsap2.Text = asap2.ToString();
                //textBoxIndikator2.Text = indikator2.ToString();
                

                labelApi3.Text = api3.ToString();
                labelAsap3.Text = asap3.ToString();
                //textBoxIndikator3.Text = indikator3.ToString();
                

                labelLongitude.Text = longitude.ToString("0.000000");
                labelLatitude.Text = lattitude.ToString("0.000000");
                //textBoxEmergency.Text = emergency.ToString();
                if (emergency == 0)
                {
                    textBoxEmergency.BackColor = System.Drawing.Color.Lime;
                    if (indikator1 == 0)
                    {
                        textBoxIndikator1.BackColor = System.Drawing.Color.Lime;
                        textBoxLabel1.Text = "Aman";
                    }
                    else
                    {
                        textBoxIndikator1.BackColor = System.Drawing.Color.Red;
                        textBoxLabel1.Text = "Kebakaran";
                    }

                    if (indikator2 == 0)
                    {
                        textBoxIndikator2.BackColor = System.Drawing.Color.Lime;
                        textBoxLabel2.Text = "Aman";
                    }
                    else
                    {
                        textBoxIndikator2.BackColor = System.Drawing.Color.Red;
                        textBoxLabel2.Text = "Kebakaran";
                    }

                    if (indikator3 == 0)
                    {
                        textBoxIndikator3.BackColor = System.Drawing.Color.Lime;
                        textBoxLabel3.Text = "Aman";
                    }
                    else
                    {
                        textBoxIndikator3.BackColor = System.Drawing.Color.Red;
                        textBoxLabel3.Text = "Kebakaran";
                    }
                }
                else
                {
                    textBoxEmergency.BackColor = System.Drawing.Color.Red;
                    textBoxIndikator1.BackColor = System.Drawing.Color.Red;
                    textBoxIndikator2.BackColor = System.Drawing.Color.Red;
                    textBoxIndikator3.BackColor = System.Drawing.Color.Red;

                    textBoxLabel1.Text = "Kebakaran";
                    textBoxLabel2.Text = "Kebakaran";
                    textBoxLabel3.Text = "Kebakaran";
                }
                    


            }
        }

        double asap1, api1, indikator1;
        double asap2, api2, indikator2;

        private void comboBoxComPort_Click(object sender, EventArgs e)
        {
            comPortAvaliable();
        }

        double asap3, api3, indikator3;

        double longitude, lattitude, emergency;

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            string dataRaw;

            dataRaw = serialPort1.ReadLine();
            dataParse = dataRaw.Split('_');

            try
            {
                if (dataParse[0] == "#")
                {
                    asap1 = Convert.ToDouble(dataParse[1]);
                    api1 = Convert.ToDouble(dataParse[2]);
                    indikator1 = Convert.ToDouble(dataParse[3]);

                    asap2 = Convert.ToDouble(dataParse[4]);
                    api2 = Convert.ToDouble(dataParse[5]);
                    indikator2 = Convert.ToDouble(dataParse[6]);

                    asap3 = Convert.ToDouble(dataParse[7]);
                    api3 = Convert.ToDouble(dataParse[8]);
                    indikator3 = Convert.ToDouble(dataParse[9]);

                    longitude = Convert.ToDouble(dataParse[10]);
                    lattitude = Convert.ToDouble(dataParse[11]);
                    emergency = Convert.ToDouble(dataParse[12]);
                }
            }
            catch { }

        }


    }
}
