﻿namespace formTemplate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.comboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.comboBoxComPort = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBoxEmergency = new System.Windows.Forms.TextBox();
            this.labelLongitude = new System.Windows.Forms.Label();
            this.labelLatitude = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxLabel3 = new System.Windows.Forms.TextBox();
            this.textBoxLabel2 = new System.Windows.Forms.TextBox();
            this.textBoxLabel1 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBoxIndikator2 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.labelApi2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.labelAsap2 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxIndikator3 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.labelApi3 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.labelAsap3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxIndikator1 = new System.Windows.Forms.TextBox();
            this.labelApi1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelAsap1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timerDisplayData = new System.Windows.Forms.Timer(this.components);
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox1);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(121, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1025, 657);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.buttonConnect);
            this.groupBox6.Controls.Add(this.comboBoxBaudRate);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.comboBoxComPort);
            this.groupBox6.Location = new System.Drawing.Point(690, 312);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(317, 323);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Serial Port";
            // 
            // buttonConnect
            // 
            this.buttonConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConnect.Location = new System.Drawing.Point(157, 221);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(137, 33);
            this.buttonConnect.TabIndex = 20;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // comboBoxBaudRate
            // 
            this.comboBoxBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBaudRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxBaudRate.FormattingEnabled = true;
            this.comboBoxBaudRate.Items.AddRange(new object[] {
            "9600"});
            this.comboBoxBaudRate.Location = new System.Drawing.Point(157, 152);
            this.comboBoxBaudRate.Name = "comboBoxBaudRate";
            this.comboBoxBaudRate.Size = new System.Drawing.Size(138, 33);
            this.comboBoxBaudRate.TabIndex = 19;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(33, 160);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(113, 25);
            this.label33.TabIndex = 18;
            this.label33.Text = "Baud Rate";
            this.label33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(33, 101);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(104, 25);
            this.label32.TabIndex = 17;
            this.label32.Text = "COM port";
            this.label32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // comboBoxComPort
            // 
            this.comboBoxComPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxComPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxComPort.FormattingEnabled = true;
            this.comboBoxComPort.Location = new System.Drawing.Point(157, 98);
            this.comboBoxComPort.Name = "comboBoxComPort";
            this.comboBoxComPort.Size = new System.Drawing.Size(138, 33);
            this.comboBoxComPort.TabIndex = 0;
            this.comboBoxComPort.Click += new System.EventHandler(this.comboBoxComPort_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBoxEmergency);
            this.groupBox5.Controls.Add(this.labelLongitude);
            this.groupBox5.Controls.Add(this.labelLatitude);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.textBoxLabel3);
            this.groupBox5.Controls.Add(this.textBoxLabel2);
            this.groupBox5.Controls.Add(this.textBoxLabel1);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Location = new System.Drawing.Point(16, 312);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(655, 323);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            // 
            // textBoxEmergency
            // 
            this.textBoxEmergency.BackColor = System.Drawing.Color.Lime;
            this.textBoxEmergency.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxEmergency.Location = new System.Drawing.Point(605, 268);
            this.textBoxEmergency.Multiline = true;
            this.textBoxEmergency.Name = "textBoxEmergency";
            this.textBoxEmergency.ReadOnly = true;
            this.textBoxEmergency.Size = new System.Drawing.Size(44, 40);
            this.textBoxEmergency.TabIndex = 17;
            // 
            // labelLongitude
            // 
            this.labelLongitude.AutoSize = true;
            this.labelLongitude.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLongitude.Location = new System.Drawing.Point(242, 283);
            this.labelLongitude.Name = "labelLongitude";
            this.labelLongitude.Size = new System.Drawing.Size(126, 25);
            this.labelLongitude.TabIndex = 16;
            this.labelLongitude.Text = "112.984727";
            this.labelLongitude.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelLatitude
            // 
            this.labelLatitude.AutoSize = true;
            this.labelLatitude.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLatitude.Location = new System.Drawing.Point(247, 244);
            this.labelLatitude.Name = "labelLatitude";
            this.labelLatitude.Size = new System.Drawing.Size(121, 25);
            this.labelLatitude.TabIndex = 15;
            this.labelLatitude.Text = "-7.4679327";
            this.labelLatitude.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(187, 283);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(18, 25);
            this.label23.TabIndex = 14;
            this.label23.Text = ":";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(187, 244);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(18, 25);
            this.label22.TabIndex = 13;
            this.label22.Text = ":";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(58, 283);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(107, 25);
            this.label21.TabIndex = 12;
            this.label21.Text = "Longitude";
            this.label21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(58, 244);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(89, 25);
            this.label20.TabIndex = 11;
            this.label20.Text = "Latitude";
            this.label20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(17, 198);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(165, 25);
            this.label19.TabIndex = 10;
            this.label19.Text = "Koordinat Kapal";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxLabel3
            // 
            this.textBoxLabel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLabel3.Location = new System.Drawing.Point(433, 98);
            this.textBoxLabel3.Name = "textBoxLabel3";
            this.textBoxLabel3.ReadOnly = true;
            this.textBoxLabel3.Size = new System.Drawing.Size(172, 31);
            this.textBoxLabel3.TabIndex = 9;
            this.textBoxLabel3.Text = "Aman";
            this.textBoxLabel3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxLabel2
            // 
            this.textBoxLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLabel2.Location = new System.Drawing.Point(232, 98);
            this.textBoxLabel2.Name = "textBoxLabel2";
            this.textBoxLabel2.ReadOnly = true;
            this.textBoxLabel2.Size = new System.Drawing.Size(171, 31);
            this.textBoxLabel2.TabIndex = 8;
            this.textBoxLabel2.Text = "Kebakaran";
            this.textBoxLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxLabel1
            // 
            this.textBoxLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLabel1.Location = new System.Drawing.Point(22, 98);
            this.textBoxLabel1.Name = "textBoxLabel1";
            this.textBoxLabel1.ReadOnly = true;
            this.textBoxLabel1.Size = new System.Drawing.Size(183, 31);
            this.textBoxLabel1.TabIndex = 7;
            this.textBoxLabel1.Text = "Aman";
            this.textBoxLabel1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(464, 37);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(120, 25);
            this.label18.TabIndex = 7;
            this.label18.Text = "Ruangan C";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(262, 37);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(119, 25);
            this.label17.TabIndex = 7;
            this.label17.Text = "Ruangan B";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(63, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 25);
            this.label16.TabIndex = 7;
            this.label16.Text = "Ruangan A";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.textBoxIndikator2);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.labelApi2);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.labelAsap2);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Location = new System.Drawing.Point(354, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 276);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(90, 177);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(18, 25);
            this.label26.TabIndex = 18;
            this.label26.Text = ":";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxIndikator2
            // 
            this.textBoxIndikator2.BackColor = System.Drawing.Color.Red;
            this.textBoxIndikator2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxIndikator2.Location = new System.Drawing.Point(267, 226);
            this.textBoxIndikator2.Multiline = true;
            this.textBoxIndikator2.Name = "textBoxIndikator2";
            this.textBoxIndikator2.ReadOnly = true;
            this.textBoxIndikator2.Size = new System.Drawing.Size(44, 40);
            this.textBoxIndikator2.TabIndex = 6;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(90, 120);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(18, 25);
            this.label27.TabIndex = 17;
            this.label27.Text = ":";
            this.label27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelApi2
            // 
            this.labelApi2.AutoSize = true;
            this.labelApi2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelApi2.Location = new System.Drawing.Point(147, 174);
            this.labelApi2.Name = "labelApi2";
            this.labelApi2.Size = new System.Drawing.Size(24, 25);
            this.labelApi2.TabIndex = 5;
            this.labelApi2.Text = "0";
            this.labelApi2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(17, 174);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 25);
            this.label12.TabIndex = 3;
            this.label12.Text = "Api";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(17, 117);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 25);
            this.label13.TabIndex = 2;
            this.label13.Text = "Asap";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelAsap2
            // 
            this.labelAsap2.AutoSize = true;
            this.labelAsap2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsap2.Location = new System.Drawing.Point(147, 117);
            this.labelAsap2.Name = "labelAsap2";
            this.labelAsap2.Size = new System.Drawing.Size(24, 25);
            this.labelAsap2.TabIndex = 1;
            this.labelAsap2.Text = "0";
            this.labelAsap2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(104, 26);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(119, 25);
            this.label15.TabIndex = 0;
            this.label15.Text = "Ruangan B";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.textBoxIndikator3);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.labelApi3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.labelAsap3);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Location = new System.Drawing.Point(690, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 276);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(104, 177);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 25);
            this.label28.TabIndex = 20;
            this.label28.Text = ":";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxIndikator3
            // 
            this.textBoxIndikator3.BackColor = System.Drawing.Color.Lime;
            this.textBoxIndikator3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxIndikator3.Location = new System.Drawing.Point(267, 226);
            this.textBoxIndikator3.Multiline = true;
            this.textBoxIndikator3.Name = "textBoxIndikator3";
            this.textBoxIndikator3.ReadOnly = true;
            this.textBoxIndikator3.Size = new System.Drawing.Size(44, 40);
            this.textBoxIndikator3.TabIndex = 6;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(104, 120);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(18, 25);
            this.label29.TabIndex = 19;
            this.label29.Text = ":";
            this.label29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelApi3
            // 
            this.labelApi3.AutoSize = true;
            this.labelApi3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelApi3.Location = new System.Drawing.Point(152, 173);
            this.labelApi3.Name = "labelApi3";
            this.labelApi3.Size = new System.Drawing.Size(24, 25);
            this.labelApi3.TabIndex = 5;
            this.labelApi3.Text = "0";
            this.labelApi3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Api";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(17, 117);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 25);
            this.label8.TabIndex = 2;
            this.label8.Text = "Asap";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelAsap3
            // 
            this.labelAsap3.AutoSize = true;
            this.labelAsap3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsap3.Location = new System.Drawing.Point(152, 116);
            this.labelAsap3.Name = "labelAsap3";
            this.labelAsap3.Size = new System.Drawing.Size(24, 25);
            this.labelAsap3.TabIndex = 1;
            this.labelAsap3.Text = "0";
            this.labelAsap3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(104, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 25);
            this.label10.TabIndex = 0;
            this.label10.Text = "Ruangan C";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.textBoxIndikator1);
            this.groupBox3.Controls.Add(this.labelApi1);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.labelAsap1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(16, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 276);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(104, 177);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(18, 25);
            this.label25.TabIndex = 16;
            this.label25.Text = ":";
            this.label25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(104, 120);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(18, 25);
            this.label24.TabIndex = 15;
            this.label24.Text = ":";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxIndikator1
            // 
            this.textBoxIndikator1.BackColor = System.Drawing.Color.Lime;
            this.textBoxIndikator1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxIndikator1.Location = new System.Drawing.Point(267, 226);
            this.textBoxIndikator1.Multiline = true;
            this.textBoxIndikator1.Name = "textBoxIndikator1";
            this.textBoxIndikator1.ReadOnly = true;
            this.textBoxIndikator1.Size = new System.Drawing.Size(44, 40);
            this.textBoxIndikator1.TabIndex = 6;
            // 
            // labelApi1
            // 
            this.labelApi1.AutoSize = true;
            this.labelApi1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelApi1.Location = new System.Drawing.Point(139, 174);
            this.labelApi1.Name = "labelApi1";
            this.labelApi1.Size = new System.Drawing.Size(24, 25);
            this.labelApi1.TabIndex = 5;
            this.labelApi1.Text = "0";
            this.labelApi1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 25);
            this.label6.TabIndex = 3;
            this.label6.Text = "Api";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 25);
            this.label5.TabIndex = 2;
            this.label5.Text = "Asap";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelAsap1
            // 
            this.labelAsap1.AutoSize = true;
            this.labelAsap1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAsap1.Location = new System.Drawing.Point(139, 117);
            this.labelAsap1.Name = "labelAsap1";
            this.labelAsap1.Size = new System.Drawing.Size(24, 25);
            this.labelAsap1.TabIndex = 1;
            this.labelAsap1.Text = "0";
            this.labelAsap1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(104, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ruangan A";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // timerDisplayData
            // 
            this.timerDisplayData.Interval = 500;
            this.timerDisplayData.Tick += new System.EventHandler(this.timerDisplayData_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelAsap1;
        private System.Windows.Forms.Label labelApi1;
        private System.Windows.Forms.TextBox textBoxIndikator1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBoxIndikator2;
        private System.Windows.Forms.Label labelApi2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labelAsap2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxIndikator3;
        private System.Windows.Forms.Label labelApi3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelAsap3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxLabel3;
        private System.Windows.Forms.TextBox textBoxLabel2;
        private System.Windows.Forms.TextBox textBoxLabel1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label labelLongitude;
        private System.Windows.Forms.Label labelLatitude;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox comboBoxComPort;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.ComboBox comboBoxBaudRate;
        private System.Windows.Forms.Label label33;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timerDisplayData;
        private System.Windows.Forms.TextBox textBoxEmergency;
    }
}

