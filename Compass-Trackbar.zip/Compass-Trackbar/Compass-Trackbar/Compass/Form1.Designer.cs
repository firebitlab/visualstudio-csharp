﻿namespace Compass
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_deg = new System.Windows.Forms.PictureBox();
            this.trackBar_deg = new System.Windows.Forms.TrackBar();
            this.label_deg = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_deg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_deg)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_deg
            // 
            this.pictureBox_deg.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox_deg.BackColor = System.Drawing.Color.Black;
            this.pictureBox_deg.Location = new System.Drawing.Point(78, 12);
            this.pictureBox_deg.Name = "pictureBox_deg";
            this.pictureBox_deg.Size = new System.Drawing.Size(353, 280);
            this.pictureBox_deg.TabIndex = 0;
            this.pictureBox_deg.TabStop = false;
            // 
            // trackBar_deg
            // 
            this.trackBar_deg.Location = new System.Drawing.Point(78, 349);
            this.trackBar_deg.Maximum = 359;
            this.trackBar_deg.Name = "trackBar_deg";
            this.trackBar_deg.Size = new System.Drawing.Size(353, 45);
            this.trackBar_deg.TabIndex = 1;
            this.trackBar_deg.Scroll += new System.EventHandler(this.trackBar_deg_Scroll);
            // 
            // label_deg
            // 
            this.label_deg.AutoSize = true;
            this.label_deg.Location = new System.Drawing.Point(78, 330);
            this.label_deg.Name = "label_deg";
            this.label_deg.Size = new System.Drawing.Size(13, 13);
            this.label_deg.TabIndex = 2;
            this.label_deg.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 429);
            this.Controls.Add(this.label_deg);
            this.Controls.Add(this.trackBar_deg);
            this.Controls.Add(this.pictureBox_deg);
            this.Name = "Form1";
            this.Text = "Compass";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_deg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_deg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_deg;
        private System.Windows.Forms.TrackBar trackBar_deg;
        private System.Windows.Forms.Label label_deg;
    }
}

